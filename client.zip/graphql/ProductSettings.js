export const GET_PRODUCT_SETTINGS = `
  query {
    getProductSettings {
      _id
      categories
      productCardType
    }
  }
`;
