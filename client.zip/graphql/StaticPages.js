export const GET_STATIC_PAGES = `
  query {
    getStaticPages {
      pageName
      pageContent
    }
  }
`;
